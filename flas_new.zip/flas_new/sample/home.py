from flask import Flask,render_template,request,send_from_directory
from werkzeug.utils import secure_filename
import sqlite3

app=Flask(__name__)

@app.route('/home',methods=['GET','POST'])
def home():
    if request.method=='POST':
        con=sqlite3.connect('sam.db')
        #con.execute('create table student(roll int,name text,age int)')
        a=int(request.form['n1'])
        b=request.form['n2']
        c=int(request.form['n3'])
        con.execute('insert into student values(?,?,?)',(a,b,c))
        d=con.execute("select * from student")
        return render_template('home.html',data=d)
    return render_template('home.html')
import os
@app.route('/index',methods=['GET','POST'])
def index():
    if request.method == 'POST':
        f=request.files['n1']
        print(f)
        name=secure_filename(f.filename)
        print(name)
        f.save(os.path.join('./media',name))
        return render_template('upload.html',x=name)
    return render_template('index.html')
@app.route('/<f>')
def upload_file(f):
    return send_from_directory('./media',f)


app.run()